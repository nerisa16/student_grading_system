<?php
// Connect to database
$conn = new mysqli("localhost", "username", "password", "database_name");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];

  if ($password != $confirm_password) {
    $error = 'Passwords do not match';
  } else {
    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
    if ($conn->query($sql) === TRUE) {
      header('Location: login.php');
      exit;
    } else {
      $error = 'Error creating account';
    }
  }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main>
    <section class="register">
      <h2>Register</h2>
      <form method="post">
        <label>Username:</label>
        <input type="text" name="username"><br>
        <label>Password:</label>
        <input type="password" name="password"><br>
        <label>Confirm Password:</label>
        <input type="password" name="confirm_password"><br>
        <input type="submit" value="Register" class="btn submit">
        <p>Already have an account? <a href="login.php">Login</a></p>
        <?php if (isset($error)) { echo '<p style="color: red;">' . $error . '</p>'; } ?>
      </form>
    </section>
  </main>
</body>
</html>

