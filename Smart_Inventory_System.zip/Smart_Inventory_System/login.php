<?php

session_start();

// Connect to database
$conn = new mysqli("localhost", "username", "password", "database_name");

// Check connection
if ($conn->connect_error) {
  die("Connection failed:  " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $_SESSION['user_id'] = $row['id'];
    header('Location: index.php');
    exit;
  } else {
    $error = 'Invalid username or password';
  }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main>
    <section class="login">
      <h2>Login</h2>
      <form method="post">
        <label>Username:</label>
        <input type="text" name="username"><br>
        <label>Password:</label>
        <input type="password" name="password"><br>
        <input type="submit" value="Login" class="btn submit">
        <p>Don't have an account? <a href="register.php">Register</a></p>
        <?php if (isset($error)) { echo '<p style="color: red;">' . $error . '</p>'; } ?>
      </form>
    </section>
  </main>
</body>
</html>


