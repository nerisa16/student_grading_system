add.php (same as before)
<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  header('Location: login.php');
  exit;
}

// Connect to database
$conn = new mysqli("localhost", "username", "password", "database_name");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $description = $_POST['description'];
  $quantity = $_POST['quantity'];
  $price = $_POST['price'];

  $sql = "INSERT INTO products (name, description, quantity, price) VALUES ('$name', '$description', $quantity, $price)";
  if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
    exit;
  } else {
    $error = 'Error adding product';
  }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Product</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main>
    <section class="add-product">
      <h2>Add Product</h2>
      <form method="post">
        <label>Name:</label>
        <input type="text" name="name"><br>
        <label>Description:</label>
        <textarea name="description"></textarea><br>
        <label>Quantity:</label>
        <input type="number" name="quantity"><br>
        <label>Price:</label>
        <input type="number" name="price" step="0.01"><br>
        <input type="submit" value="Add Product" class="btn submit">
        <?php if (isset($error)) { echo '<p style="color: red;">' . $error . '</p>'; } ?>
      </form>
    </section>
  </main>
</body>
</html>

